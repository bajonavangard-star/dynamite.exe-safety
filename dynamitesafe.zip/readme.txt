dynamite.exe
This malware is so insane.
Credits to pan koza 2 for this payloads (from Getaparane.exe, DETTAMROFNIW.exe, Hexachlorocyclohexane.exe)
Credits to ArTicZera for this blur effect.
Works in Windows XP / Windows 11
Creation Date: 11/05/2026 (November 5, 2026)

Damage Rate: Destructive

Warning!
Running on your real device will overwrite MBR.
So use a virtual machine instead.

Written in: C++ (used in Dev C++ 5.11)
So it is AI, but peak.